﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3_4___Hash_Table
{
    class Prices
    {
        public static double CowMilkPrice;
        public static double GoatMilkPrice;

        public static double CowVaccineCost;
        public static double JerseyVaccineCost;
        public static double GoatVaccineCost;
    }
}
