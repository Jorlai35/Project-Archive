﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_3_4___Hash_Table
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Run_Click(object sender, EventArgs e)
        {
            //reading lines from teh txt file into a string array to be sorted into a dictionary
            string[] fileContents = File.ReadAllLines(@"file.txt");
            string[] A;
            Dictionary<int, Animals> D = new Dictionary<int, Animals>();

            //loop that splits each line and creates the right object
            Prices.CowMilkPrice = Convert.ToDouble(Cmilk.Text);
            Prices.GoatMilkPrice = Convert.ToDouble(Gmilk.Text);

            Prices.CowVaccineCost = Convert.ToDouble(Cvaccine.Text);
            Prices.JerseyVaccineCost = Convert.ToDouble(Jvaccine.Text);
            Prices.GoatVaccineCost = Convert.ToDouble(Gvaccine.Text);
            foreach (string s in fileContents)
            {
                A = s.Split(',');
                switch (A[2])
                {
                    case "Cow":
                        D.Add(Int32.Parse(A[0]), new Cow(Int32.Parse(A[0]), Double.Parse(A[1])));
                        break;
                    case "Jersey_Cow":
                        D.Add(Int32.Parse(A[0]), new Jersey_Cow(Int32.Parse(A[0]), Double.Parse(A[1])));
                        break;
                    case "Goat":
                        D.Add(Int32.Parse(A[0]), new Goat(Int32.Parse(A[0]), Double.Parse(A[1])));
                        break;
                }
            }

            Output.Text = Iteration(D);
            
        }

        //the loop that creates a string with teh desired output by looping through all values and runs the Profitability() method
        static string Iteration(Dictionary<int, Animals> D)
        {
            double d = 0;
            string s = "";
            foreach (KeyValuePair<int, Animals> x in D)
            {
                s += $"ID {x.Value.iD}: ${x.Value.Profitability()} \r\n";
                d += x.Value.Profitability();
            }
            s += $"Total Profitability: ${d}";
            return s;
        }
    }
}
