﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3_4___Hash_Table
{
    class Goat : Animals
    {
        public Goat(int id, double mQty) : base(id, mQty)
        {

        }

        public override double Profitability()
        {
            return 365 * (mQty * Prices.GoatMilkPrice) - Prices.GoatVaccineCost;
        }
    }
}
