﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3_4___Hash_Table
{
    class Animals
    {
        public int iD;
        public double mQty;

        public Animals(int iD, double mQty)
        {
            this.iD = iD;
            this.mQty = mQty;
        }

        public virtual double Profitability()
        {
            return 0;
        }
    }
}
