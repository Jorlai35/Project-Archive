﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3_4___Hash_Table
{
    class Cow : Animals
    {
        public Cow(int id, double mQty) : base(id,mQty)
        {

        }

        public override double Profitability()
        {
            return 365 * (mQty * Prices.CowMilkPrice) - Prices.CowVaccineCost;
        }
    }
}
