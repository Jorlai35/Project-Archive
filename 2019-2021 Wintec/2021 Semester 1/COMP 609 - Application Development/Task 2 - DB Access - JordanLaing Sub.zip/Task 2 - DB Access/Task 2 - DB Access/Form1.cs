﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Task_2___DB_Access
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Creation of the location for the connection file and base of query
            String connStr = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source = FarmInformation.accdb; Persist Security Info = False";
            String sqlQuery = "SELECT * FROM ";
            OleDbConnection conn = null;
            try
            {
                //Add the inputted table name into the query and creation of the connection
                sqlQuery += textBox1.Text;
                conn = new OleDbConnection(connStr);
                conn.Open();
                OleDbCommand cmd = new OleDbCommand(sqlQuery, conn);
                string str = "";

                //runs the query through the DB
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    //Output of column names
                    for (int x = 0; x < reader.FieldCount; x++)
                        str += $"{reader.GetName(x),-25}";
                    str += "\r\n";

                    //Output of the row values
                    while (reader.Read()) {
                        for (int i = 0; i < reader.FieldCount; i++)
                            str += $"{reader[i].ToString(),-25}";
                        str += "\r\n";
                    }
                    textBox2.Paste(str);
                }
                conn.Close();

            }
            //Displays any error that shows
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }     
        }
    }
}
