﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace Overall_App
{
    public partial class Form1 : Form
    {
        //Grade - 98

        //short methods - 3 marks
        //self marking - 2 marks
        //testing evidence - 3 marks
        public Form1()
        {
            InitializeComponent();
        }
        private void Setup_Click(object sender, EventArgs e)
        {
            Dictionary<int, Animals> D = new Dictionary<int, Animals>();
            String connStr = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source = FarmInformation.accdb; Persist Security Info = False";
            OleDbConnection conn = null;
            try
            {
                conn = new OleDbConnection(connStr);
                //Rewrite so its easier to read
                conn.Open();
                DBReading("Cows", conn, D);
                DBReading("Dogs", conn, D);
                DBReading("Goats", conn, D);
                DBReading("Sheep", conn, D);
                DBReading("CommodityPrices", conn, D);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Reports.D = D;

            //Change Visibility
            Setup.Visible = false;
            label3.Visible = false;
            label1.Visible = true;
            ReportNum.Visible = true;
            Output.Visible = true;
            button1.Visible = true;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            
            switch(ReportNum.Text)
            {
                case "1":
                    try { Output.Text = Reports.Report1(Int32.Parse(IdNum.Text)); }
                    catch { Output.Text = "Inputed Id is either empty or includes an invalid character.\r\nEnsure input is an Interger."; }
                    break;
                case "2":
                    Output.Text = $"Total farm profit(Daily): ${Reports.Report2():0.00}";
                    break;
                case "3":
                    Output.Text = $"Tax Paid(Monthly): ${Reports.Report3():0.00}";
                    break;
                case "4":
                    Output.Text = Reports.Report4();
                    break;
                case "5":
                    Output.Text = $"Average Age: {Reports.Report5()}";
                    break;
                case "6":
                    Output.Text = Reports.Report6();
                    break;
                case "7":
                    Output.Text = Reports.Report7();
                    break;
                case "8":
                    Reports.Report8("TestOutput.txt");
                    Output.Text = "File created with the Ids in order by profitability.";
                    break;
                case "9":
                    Output.Text = $"The percentage of red animals: {Reports.Report9():0.00}%";
                    break;
                case "10":
                    Output.Text = $"Total tax paid by jersey cows: ${Reports.Report10():0.00}";
                    break;
                case "11":
                    try 
                    {
                        if (Convert.ToInt32(IdNum.Text) > 0) Output.Text = $"Percentage above age {IdNum.Text}yrs is {Reports.Report11(Convert.ToInt32(IdNum.Text)):0.00}%";
                        else Output.Text = "Age is required to be above 0yrs.";
                    }
                    catch { Output.Text = "Inputed age is either empty or includes an invalid character.\r\nEnsure input is an Interger."; }
                    break;
                case "12":
                    Output.Text = $"Total Profitability of Jersey cows: ${Reports.Report12():0.00}";
                    break;
                default:
                    Output.Text = "Report number entered is invalid. \r\nEnter as an Interger. Range is 1 to 12.";
                    break;
            }
        }

        //Method to read the database and create objects
        static void DBReading(string end, OleDbConnection conn, Dictionary<int, Animals> D)
        {
            string sqlQuery = "SELECT * FROM ";
            OleDbCommand cmd = new OleDbCommand(sqlQuery + end, conn);
            using (OleDbDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    //switch determines what table is being read to create the right object
                    switch (end)
                    {
                        case "Cows":
                            if (Convert.ToBoolean(reader[7]))
                                D[Convert.ToInt32(reader[0])] = new Jersy(Convert.ToInt32(reader[0]), Convert.ToDouble(reader[1]), Convert.ToDouble(reader[2]), Convert.ToDouble(reader[3]), Convert.ToInt32(reader[4]), reader[5].ToString(), Convert.ToBoolean(reader[7]), Convert.ToDouble(reader[6]));
                            else
                                D[Convert.ToInt32(reader[0])] = new Cow(Convert.ToInt32(reader[0]), Convert.ToDouble(reader[1]), Convert.ToDouble(reader[2]), Convert.ToDouble(reader[3]), Convert.ToInt32(reader[4]), reader[5].ToString(), Convert.ToBoolean(reader[7]), Convert.ToDouble(reader[6]));
                            break;
                        case "Dogs":
                            D[Convert.ToInt32(reader[0])] = new Dogs(Convert.ToInt32(reader[0]), Convert.ToDouble(reader[1]), Convert.ToDouble(reader[5]), Convert.ToDouble(reader[2]), Convert.ToInt32(reader[3]), reader[4].ToString());
                            break;
                        case "Goats":
                            D[Convert.ToInt32(reader[0])] = new Goat(Convert.ToInt32(reader[0]), Convert.ToDouble(reader[1]), Convert.ToDouble(reader[2]), Convert.ToDouble(reader[3]), Convert.ToInt32(reader[4]), reader[5].ToString(), Convert.ToDouble(reader[6]));
                            break;
                        case "Sheep":
                            D[Convert.ToInt32(reader[0])] = new Sheep(Convert.ToInt32(reader[0]), Convert.ToDouble(reader[1]), Convert.ToDouble(reader[2]), Convert.ToDouble(reader[3]), Convert.ToInt32(reader[4]), reader[5].ToString(), Convert.ToDouble(reader[6]));
                            break;
                        //case for commodity prices uses another switch to asign the right rows values in prices class
                        case "CommodityPrices":
                            switch (reader[0].ToString())
                            {
                                case "Goat milk price":
                                    Prices.GoatMilkPrice = Convert.ToDouble(reader[1]);
                                    break;
                                case "Sheep wool price":
                                    Prices.SheepWoolPrice = Convert.ToDouble(reader[1]);
                                    break;
                                case "Water price":
                                    Prices.WaterCost = Convert.ToDouble(reader[1]);
                                    break;
                                case "Government tax per kg":
                                    Prices.Tax = Convert.ToDouble(reader[1]);
                                    break;
                                case "Jersy cow tax":
                                    Prices.JersyTax = Convert.ToDouble(reader[1]);
                                    break;
                                case "Cow milk price":
                                    Prices.CowMilkPrice = Convert.ToDouble(reader[1]);
                                    break;
                            }
                            break;
                    }
                }
            }
        }

        //Used to check if the inputted report number requires a second input (1 and 11)
        private void ReportNum_TextChanged(object sender, EventArgs e)
        {
            switch (ReportNum.Text)
            {
                case "1":
                    label2.Visible = true;
                    IdNum.Visible = true;
                    label2.Text = "ID:";
                    break;
                case "11":
                    label2.Visible = true;
                    IdNum.Visible = true;
                    label2.Text = "Age(Years):";
                    break;
                default:
                    label2.Visible = false;
                    IdNum.Visible = false;
                    break;
            }
        }//End of Text changed

        
    }
}
