﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Prices
    {
        public static double CowMilkPrice;
        public static double GoatMilkPrice;
        public static double SheepWoolPrice;
        public static double WaterCost;
        public static double Tax;
        public static double JersyTax;
    }
}
