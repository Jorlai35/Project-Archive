﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class QuickSort
    {
        public static void Sort(Animals[] A, int start, int end)
        {
            int i;
            if (start < end)
            {
                //if i stays 0 it means that the first value is the minimum for this range
                i = Partition(A, start, end);

                //Recurrance
                Sort(A, start, i - 1);
                Sort(A, i + 1, end);
            }
        }//End of QuickSort(Array, start, end)

        static int Partition(Animals[] A, int start, int end)
        {
            Animals temp;
            double p = A[end].getProfitability();
            int i = start - 1;
            for (int j = start; j < end; j++)
            {
                if (A[j].getProfitability() <= p)
                {
                    i++;
                    temp = A[i];
                    A[i] = A[j];
                    A[j] = temp;
                }
            }
            //i is the last index changed meaning everything greater than that index is larger than the end
            temp = A[i + 1];
            A[i + 1] = A[end];
            A[end] = temp;
            return i + 1;
        }//End of Partition(Array, start, end) - part of QuickSort(Array, start, end)
    }
    
}
