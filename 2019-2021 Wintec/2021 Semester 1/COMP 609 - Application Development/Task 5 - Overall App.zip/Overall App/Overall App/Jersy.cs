﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Jersy : Cow
    {
        public Jersy(int id, double water, double cost, double weight, int age, string colour, bool jersy, double mAmount) : base(id, water, cost, weight, age, colour, jersy, mAmount)
        {

        }

        public override double TotalTax()
        {
            double result = (Prices.JersyTax * weight);
            return result;
        }
    }
}
