﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Sheep : Animals
    {
        double woolAmount;
        public Sheep(int id, double water, double cost, double weight, int age, string colour, double woolAmount) : base(id, water, cost, weight, age, colour)
        {
            this.woolAmount = woolAmount;
        }
        public override string returnInfo()
        {
            string s = "";
            s += $"Id: {id}\r\nType: Sheep\r\nColour: {colour}\r\nAge: {age}\r\nWeight: {weight}Kg\r\nWater Usage: {water}L\r\nDaily Cost: ${cost}\r\nWool Produced Yearly: {woolAmount}Kg\r\nProfitability: {this.getProfitability():0.00}\r\n";
            s += "------------------------------\r\n";
            return s;
        }

        public override double getProfitability()
        {
            double profit = (woolAmount / 365) * Prices.SheepWoolPrice;
            return (profit - TotalCost());
        }
    }
}
