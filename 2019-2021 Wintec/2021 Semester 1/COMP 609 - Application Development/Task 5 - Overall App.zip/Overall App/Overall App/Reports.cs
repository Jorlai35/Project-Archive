﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Overall_App
{
    class Reports
    {
        public static Dictionary<int, Animals> D;

        public static string Report1(int ID)
        {
            string s = "";
            try
            {
                s = D[ID].returnInfo();
            }
            catch
            {
                s = "Error: Could not find animals ID.";
            }
            return s;
        }//End of Report1(Dictionary, int Id)

        public static double Report2()
        {
            double Profit = 0;
            foreach (Animals A in D.Values)
            {
                Profit += A.getProfitability();
            }
            return Profit;
        }//End of Report2(Dictionary)

        public static double Report3()
        {
            double total = 0;
            foreach (Animals A in D.Values)
            {
                //Total tax is daily so 30 days for the month
                total += A.TotalTax() * 30;
            }
            return total;
        }//End of Report3(Dictionary)

        public static string Report4()
        {
            string s = "Total Milk: ";
            double total = 0;
            foreach (Animals A in D.Values)
            {
                total += A.Milk();
            }
            return s += $"{total}L";
        }//End of Report4(Dictionary)

        public static double Report5()
        {
            int count = 0;
            double total = 0;
            foreach (Animals A in D.Values)
            {
                if (!(A is Dogs))
                {
                    total += A.getAge();
                    count++;
                }
            }
            return total / count;
        }//End of Report5(Dictionary)

        public static string Report6()
        {
            string s = "";
            int countCG = 0;
            double totalCG = 0;
            int countS = 0;
            double totalS = 0;
            foreach (Animals A in D.Values)
            {
                if (A is Sheep)
                {
                    totalS += A.getProfitability();
                    countS++;
                }
                if (A is Cow || A is Goat || A is Jersy)
                {
                    totalCG += A.getProfitability();
                    countCG++;
                }
            }
            s += $"Profit ratio (Cow & Goat Vs Sheep): ${totalCG / countCG:0.00} Vs ${totalS / countS:0.00}";
            return s;
        }//End of Report6(Dictionary)

        public static string Report7()
        {
            string s = "";
            double dCost = 0;
            double aCost = 0;
            foreach (Animals A in D.Values)
            {
                if (A is Dogs)
                {
                    dCost += A.TotalCost();
                }
                aCost += A.TotalCost();
            }
            s = $"Total cost(Dog Vs Total): ${dCost} Vs ${aCost}";
            return s;
        }//End of Report7(Dictionary)

        public static void Report8(string dir)
        {
            //Puts all dictionary values into an Array for easier index manipulation
            Animals[] A = new Animals[D.Count];
            int i = -1;
            foreach (Animals p in D.Values)
            {
                if (!(p is Dogs))
                {
                    i++;
                    A[i] = p;
                }
            }
            //uses i as the end because all values after are null from array initilization size
            QuickSort.Sort(A, 0, i);

            //creates a string array to allow writing to a file
            string[] s = new string[i+1];
            for (int j = 0; j <= i; j++)
                s[j] = A[j].id.ToString();

            File.WriteAllLines(dir, s);
        }//End of Report8(Dictionary, FilePath)

        //Question if lifestock means dogs or not
        public static double Report9()
        {
            double percent = 0;
            int count = 0;
            foreach (Animals p in D.Values)
            {
                if (p.getColour() == "Red")
                    percent++;
                count++;
            }
            percent = (percent / count) * 100;
            return percent;
        }//End of Report9(Dictionary)

        public static double Report10()
        {
            double total = 0;
            foreach (Animals p in D.Values)
            {
                if (p is Jersy)
                {
                    total += p.TotalTax();
                }
            }
            return total;
        }//End of Report10(Dictionary)

        public static double Report11(int Age)
        {
            double percent = 0;
            int count = 0;
            foreach (Animals p in D.Values)
            {
                if (p.getAge() > Age)
                    percent++;
                count++;
            }
            percent = (percent / count) * 100;
            return percent;
        }//End of Report11(Dictionary, int Age)

        public static double Report12()
        {
            double total = 0;
            foreach (Animals P in D.Values)
            {
                if (P is Jersy)
                {
                    total += P.getProfitability();
                }
            }
            return total;
        }//End of Report12(Dictionary)
    }
}
