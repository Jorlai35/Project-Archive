﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Cow : Animals
    {
        bool jersy;
        public double mAmount;

        public Cow(int id, double water, double cost, double weight, int age, string colour, bool jersy, double mAmount) : base(id, water, cost, weight, age, colour)
        {
            this.jersy = jersy;
            this.mAmount = mAmount;
        }

        public bool isJersy()
        {
            return jersy;
        }
        public override string returnInfo()
        {
            string s = "";
            s += $"Id: {id}\r\nType: Cow\r\nColour: {colour}\r\nAge: {age}\r\nWeight: {weight}Kg\r\nWater Usage: {water}L\r\nDaily Cost: ${cost}\r\nMilk produced: {mAmount}L\r\nJersy: {jersy}\r\nProfitability: {this.getProfitability():0.00}\r\n";
            s += "------------------------------\r\n";
            return s;
        }

        public override double getProfitability()
        {
            double profit = (mAmount * Prices.CowMilkPrice);
            return (profit - TotalCost());
        }

        public override double Milk()
        {
            return mAmount;
        }

    }
}
