﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Goat : Animals
    {
        double milkAmount;
        public Goat(int id, double water, double cost, double weight, int age, string colour, double milkAmount) : base(id, water, cost, weight, age, colour)
        {
            this.milkAmount = milkAmount;
        }

        public override string returnInfo()
        {
            string s = "";
            s += $"Id: {id}\r\nType: Goat\r\nColour: {colour}\r\nAge: {age}\r\nWeight: {weight}Kg\r\nWater Usage: {water}L\r\nDaily Cost: ${cost}\r\nMilk produced: {milkAmount}L\r\nProfitability: {this.getProfitability():0.00}\r\n";
            s += "------------------------------\r\n";
            return s;
        }

        public override double Milk()
        {
            return milkAmount;
        }

        public override double getProfitability()
        {
            double profit = (milkAmount * Prices.GoatMilkPrice);
            return (profit - TotalCost());
        }
    }
}
