﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Animals
    {
        public int id;
        protected double water;
        protected double cost;
        protected double weight;
        protected int age;
        protected string colour;

        public Animals(int id, double water, double cost, double weight,int age, string colour)
        {
            this.id = id;
            this.water = water;
            this.cost = cost;
            this.weight = weight;
            this.age = age;
            this.colour = colour;
        }
        public virtual string returnInfo()
        {
            string s = "";
            s += $"Id: {id}\r\nType: Dog\r\nColour: {colour}\r\nAge: {age}\r\nWeight: {weight}Kg\r\nWater Usage: {water}L\r\nDaily Cost: ${cost}\r\n";
            s += "------------------------------\r\n";
            return s;
        }

        //This includes water cost
        public double TotalCost()
        {
            double expense = cost + (water * Prices.WaterCost) + TotalTax();
            return expense;
        }

        //Rewrite so this method is for dog and cows goats and sheep are in their respective classes
        public virtual double TotalTax()
        {
            double result = (Prices.Tax * weight);
            if (this is Dogs)
                result = 0;
            return result;
        }

        public virtual double getProfitability()
        {
            return 0;
        }

        public virtual double Milk()
        {
            return 0;
        }

        public int getAge()
        {
            return age;
        }

        public string getColour()
        {
            return colour;
        }
    }
}
