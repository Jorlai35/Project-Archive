﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overall_App
{
    class Dogs : Animals
    {

        public Dogs(int id, double water, double cost, double weight, int age, string colour) :base(id, water, cost, weight, age, colour)
        {

        }

    }
}
