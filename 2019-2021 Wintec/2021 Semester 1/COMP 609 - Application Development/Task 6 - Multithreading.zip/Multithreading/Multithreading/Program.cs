﻿using System;
using System.Diagnostics;
using System.Threading;

namespace Multithreading
{
    class Program
    {
        //these variables are easily edited for testing and all programming will work when these values are changed
        public static int[] A = new int[10000000];
        public static int range;
        public static int[] results;
        static void Main(string[] args)
        {
            //Creation of variables and the population of the random array
            Random rand = new Random();
            int n = 0;
            for(int i = 0; i < A.Length; i++)
            {
                n = rand.Next(A.Length);
                A[i] = n;
            }
            Console.WriteLine(calc(1));
            Console.WriteLine(calc(2));
            Console.WriteLine(calc(4));
            Console.WriteLine(calc(8));
            Console.WriteLine(calc(16));
            Console.ReadLine();
        }
        public static string calc(int nThreads)
        {
            range = A.Length / nThreads;
            Thread[] threads = new Thread[nThreads];
            results = new int[nThreads];
            Stopwatch time = new Stopwatch();
            //loop to create the threads
            for (int i = 0; i < nThreads; i++)
                threads[i] = new Thread(Execute);
            time.Start();
            for (int i = 0; i < nThreads; i++)
                threads[i].Start(i + 1);
            //this is a checker to ensure all threads are done calculating before displaying results
            for (int i = 0; i < nThreads; i++)
                threads[i].Join();
            time.Stop();
            //The display of results
            int max = 0;
            for (int i = 0; i < nThreads; i++)
                if (results[i] > results[max]) max = i;
            return ($"Total Maximum: {results[max]}\r\nTime taken (ms): {time.ElapsedMilliseconds}\r\nNumber of threads: {nThreads}\r\n---------------------");
        }
        public static void Execute(object oThread)
        {
            int nThread = Convert.ToInt32(oThread);
            int end = nThread * range;
            int max = A[(nThread - 1) * range];
            //Console.WriteLine($"i: {nThread} max: {max} range: {range} end:{end}");
            for (int i = range * (nThread-1); i < end; i++)
            {
                if (A[i] > max) max = A[i];
            }
            //Console.WriteLine($"Thread {nThread}: {max}");
            results[nThread - 1] = max;
        }
    }
}
