﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace TrialDiv___Rework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stopwatch time = new Stopwatch();
            time.Start();

            //initilisation of all the used values
            int max = 0;
            int min = 0;
            textBox3.Clear();
            StringBuilder sb = new StringBuilder();
            try
            {
                //Determines what textbox has the min and max
                if (Int32.Parse(textBox1.Text) > Int32.Parse(textBox2.Text))
                {
                    max = Int32.Parse(textBox1.Text);
                    min = Int32.Parse(textBox2.Text);
                }
                else
                {
                    max = Int32.Parse(textBox2.Text);
                    min = Int32.Parse(textBox1.Text);
                }
            }
            catch
            {
                //Catches if the text box isnt only a number
                textBox3.Paste("ERROR - Only numbers can be entered in the textboxes");
            }

            int root = Convert.ToInt32(Math.Sqrt(max));

            //creates a list with the primes that are lower than the root of given max (to caculate the primes in the range of min and max)
            List<int> li = LoopRange(new List<int>(), 2, root); 

            //uses the initiated list of primes for the wanted range
            li = LoopRange(li, min, max);

            int x = 0;

            //loop for formatting output (5 in a row)
            foreach (int n in li)
            {
                if (n > min)
                {
                    if (x < 4)
                    {
                        sb.Append(n + ", ");
                        x++;
                    }
                    else
                    {
                        sb.AppendLine(n + ", ");
                        x = 0;
                    }
                }
            }
            //Output is set from the StringBuilder
            textBox3.Paste(sb.ToString());
            time.Stop();
            MessageBox.Show("Elapsed time: " + time.ElapsedMilliseconds.ToString() + "ms");
        }


        //Function the loops between the specified range and checks primes
        public List<int> LoopRange(List<int> li, int Min, int Max)
        {
            for (int i = Min; i < Max; i++)
            {
                if (li.Count() > 0)
                    if (i < li[li.Count() - 1])
                        continue;
                if (tDevision(i, li))
                    li.Add(i);
            }
            return li;
        }


        //checks if the given number is prime by using previous primes (Sieve of Eratosthenes)
        public bool tDevision(int n, List<int> list)
        {
            bool b = true;
            int root = Convert.ToInt32(Math.Sqrt(n));
            if (n > 2)
            {
                foreach (int p in list)
                {
                    if (p > root)
                        break;
                    if (n % p == 0)
                    {
                        b = false;
                        break;
                    }
                }
            }
            if (n < 2) b = false;
            return b;
        }
    }
}
