﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Task_3___Inheritance_and_Polymorphism
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] fileContents = File.ReadAllLines(@"file.txt");
            string[] s;
            Lifestock[] stock = new Lifestock[fileContents.Length];

            for (int i = 0; i < fileContents.Length; i++)
            {
                s = fileContents[i].Split(',');
                switch (s[2])
                {
                    case "Cow":
                        stock[i] = new Cow(Int32.Parse(s[0]), Double.Parse(s[1]), Double.Parse(CowMilk.Text), Double.Parse(CowVaccine.Text));
                        break;
                    case "Jersey_Cow":
                        stock[i] = new Jersey(Int32.Parse(s[0]), Double.Parse(s[1]), Double.Parse(CowMilk.Text), Double.Parse(JCowVaccine.Text));
                        break;
                    case "Goat":
                        stock[i] = new Goat(Int32.Parse(s[0]), Double.Parse(s[1]), Double.Parse(GoatMilk.Text), Double.Parse(GoatVaccine.Text));
                        break;
                    default:
                        break;
                }
            }

            double total = 0;
            for (int i = 0; i < stock.Length; i++)
                total += stock[i].getTotalProfitability();

            Output.Paste(total.ToString());















        }
    }

    public class Lifestock
    {
        protected int id;
        protected double milkQty;
        protected double milkCost;
        protected double vaccineCost;
        public Lifestock(int id, double milkQty, double mC, double vC)
        {
            this.id = id;
            this.milkQty = milkQty;
            milkCost = mC;
            vaccineCost = vC;
        }

        public double getTotalProfitability()
        {
            return (milkQty * 365) - vaccineCost;
        }

    }

    public class Cow : Lifestock
    {
        public Cow(int id, double milkQty, double mC, double vC) : base(id, milkQty, mC, vC)
        {

        }
    }

    public class Jersey : Cow
    {
        public Jersey(int id, double milkQty, double mC, double vC) : base(id, milkQty, mC, vC)
        {

        }
    }

    public class Goat : Lifestock
    {
        public Goat(int id, double milkQty, double mC, double vC) : base(id, milkQty, mC, vC)
        {
            
        }
    }

}
