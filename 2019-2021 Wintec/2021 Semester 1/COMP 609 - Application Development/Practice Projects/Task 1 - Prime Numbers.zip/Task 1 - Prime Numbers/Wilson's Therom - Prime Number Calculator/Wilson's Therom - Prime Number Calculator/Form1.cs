﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wilson_s_Therom___Prime_Number_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            int pMax = 0;
            int n = 1;
            try
            {
                pMax = Int32.Parse(textBox1.Text);
            }
            catch
            {
                //
            }
            for(int i = 1; i <= pMax; i++)
            {
                if ((n + 1) % i == 0)
                    listView1.Items.Add(i.ToString());
                n = n * i;
            }
        }
    }
}
