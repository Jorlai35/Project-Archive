﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trial_Devision___Prime_Numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //initilisation of all the used values
            int max = 0;
            int min = 0;
            List<int> list = new List<int>();
            textBox3.Clear();
            StringBuilder sb = new StringBuilder();
            try
            {
                //Determines what textbox has the min and max
                if (Int32.Parse(textBox1.Text) > Int32.Parse(textBox2.Text))
                {
                    max = Int32.Parse(textBox1.Text);
                    min = Int32.Parse(textBox2.Text);
                }
                else
                {
                    max = Int32.Parse(textBox2.Text);
                    min = Int32.Parse(textBox1.Text);
                }
            }
            catch
            {
                //Catches if the text box isnt only a number
                textBox3.Paste("ERROR - Only numbers can be entered in the textboxes");
            }

            //the loop that sets the range for the calculations
            int x = 1;
            for (int i = 2; i <= max; i++)
            {
                if (tDevision(i, list))
                {
                    list.Add(i);
                    if (i > min)
                    {
                        if (x < 5)
                            sb.Append(i + ", ");
                        else
                        {
                            sb.AppendLine(i + ", ");
                            x = 0;
                        }
                        x++;
                    }
                }
                    
            }
            //Output is set from the StringBuilder
            textBox3.Paste(sb.ToString());
        }


        //Calculates if the given number is prime by using previous primes (Sieve of Eratosthenes)
        public bool tDevision(int n, List<int> list)
        {
            int root = Convert.ToInt32(Math.Sqrt(n));
            if (n == 2)
                return true;
            foreach (int p in list)
            {
                if (p > root)
                    break;
                if (n % p == 0)
                    return false;
            }
            return true;
        }
    }
}
