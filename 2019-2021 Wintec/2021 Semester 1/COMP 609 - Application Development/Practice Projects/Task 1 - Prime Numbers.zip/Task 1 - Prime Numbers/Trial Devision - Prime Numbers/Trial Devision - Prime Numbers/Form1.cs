﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trial_Devision___Prime_Numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //initilisation of all the used values
            int max = 0;
            int min = 0;
            textBox3.Clear();
            StringBuilder sb = new StringBuilder();
            try
            {
                //Determines what textbox has the min and max
                if (Int32.Parse(textBox1.Text) > Int32.Parse(textBox2.Text))
                {
                    max = Int32.Parse(textBox1.Text);
                    min = Int32.Parse(textBox2.Text);
                }
                else
                {
                    max = Int32.Parse(textBox2.Text);
                    min = Int32.Parse(textBox1.Text);
                }
            }
            catch
            {
                //Catches if the text box isnt only a number
                textBox3.Paste("ERROR - Only numbers can be entered in the textboxes");
            }

            List<int> li = new List<int>();
            int root = Math.Sqrt(max);
            li = LoopRange(li, 2, root);

            int x = 0;
            foreach (int n in li)
            {
                if (n > min)
                {
                    if (x < 5)
                        sb.Append(n, ", ");
                    else
                        sb.AppendLine(n, ", ");
                }
            }
            //Output is set from the StringBuilder
            textBox3.Paste(sb.ToString());
        }



        public List<int> LoopRange(List<int> li, int Min, int Max)
        {
            for (int i = Min; i < Max; i++)
            {
                if (tDevision(i, li))
                    li.Add(i);
            }
            return li;
        } 


        //Calculates if the given number is prime by using previous primes (Sieve of Eratosthenes)
        public bool tDevision(int n, List<int> list)
        {
            int root = Convert.ToInt32(Math.Sqrt(n));
            if (n == 2)
                return true;
            foreach (int p in list)
            {
                if (p > root)
                    break;
                if (n % p == 0)
                    return false;
            }
            return true;
        }
    }
}
