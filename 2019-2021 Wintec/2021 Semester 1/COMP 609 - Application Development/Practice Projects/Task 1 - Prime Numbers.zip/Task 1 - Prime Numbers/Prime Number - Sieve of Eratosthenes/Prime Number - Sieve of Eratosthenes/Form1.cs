﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prime_Number___Sieve_of_Eratosthenes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int pMax = 0;
            List<int> list = new List<int>();
            listView1.Items.Clear();
            try
            {
                pMax = Int32.Parse(textBox1.Text);
            }
            catch
            {
                //cant be bothered dropped program because slow
            }
            for (int i = 0; i <= pMax; i++)
            {
                list.Add(i);
            }
            List<int> sPrimes = Sieve(list, 2, pMax);
            //foreach(int i in sPrimes)
            //{
            //    listView1.Items.Add(i.ToString());
            //}
            listView1.Items.Add(sPrimes.Count.ToString());
        }

        public List<int> Sieve(List<int> list, int p, int max)
        {
            int i = p;
            while (p * i <= max) {
                if (list.Contains(p * i)){
                    list.Remove(p * i);
                }
                i++;
            }

            p = list[list.IndexOf(p) + 1];
            if (p * p > max)
                return list;
            else
                return Sieve(list, p, max);
        }
    }
}
