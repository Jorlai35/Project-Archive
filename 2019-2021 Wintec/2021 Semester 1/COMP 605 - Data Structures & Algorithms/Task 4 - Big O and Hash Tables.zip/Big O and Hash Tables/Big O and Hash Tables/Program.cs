﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Big_O_and_Hash_Tables
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] fileContents = File.ReadAllLines(@"file.txt");
            Dictionary<string, int> D = new Dictionary<string, int>();
            string[] splitLine;

            //this counts the freqency of the words in the file
            foreach(string line in fileContents)
            {
                splitLine = line.Split(" ");
                foreach(string sline in splitLine)
                {
                    if (D.ContainsKey(sline)) D[sline] += 1;
                    else D.Add(sline, 1);
                }
            }

            //This is used to display the frequency of the words
            string max = "";
            foreach(KeyValuePair<string,int> K in D)
            {
                if (max == "") max = K.Key;
                else if (K.Value > D[max]) max = K.Key;
                //Console.WriteLine($"Key: {K.Key} Frequency: {K.Value}");
            }
            Console.WriteLine($"Most frequent: {max}\nFrequency: {D[max]}");
            
        }
    }
}
