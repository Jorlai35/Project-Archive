﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_3___Binary_Search_Tree
{
    class Que
    {
        QueNode head;
        QueNode tail;

        public Que()
        {

        }//End of Constructor()
        public Que(QueNode n)
        {
            Add(n);
        }//End of Constructor(Initital Node)

        public void Add(QueNode n)
        {
            QueNode temp = tail;
            if (tail == null & head == null)
            {
                tail = n;
                head = n;
            }
            else
            {
                temp.next = n;
                tail = n;
            }
        }//End of Add(Que Node)

        public void Display()
        {
            QueNode n = head;
            //loop to display entire Que's Values
            while (true)
            {
                if (n == null) break;
                Console.WriteLine($"Level: {n.level} Value: {n.node.data}");
                n = n.next;
            }
        }//End of Display()
    }
}
