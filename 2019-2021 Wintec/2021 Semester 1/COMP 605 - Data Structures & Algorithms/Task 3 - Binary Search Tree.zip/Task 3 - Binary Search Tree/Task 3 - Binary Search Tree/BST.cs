﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_3___Binary_Search_Tree
{
    class BST
    {
        public Node root;
        public BST()
        {
            root = null;
        }//End of constructor

        public void addNode(Node N)
        {
            Node p = root;
            while (root != null)
            {
                if (N.data < p.data)
                {
                    if (p.left == null)
                    {
                        p.left = N;
                        break;
                    }
                    p = p.left;
                }
                else
                {
                    if (p.right == null)
                    {
                        p.right = N;
                        break;
                    }
                    p = p.right;
                }
            }//End of while(root != null) loop
            if (root == null)
                root = N;
        }//End of addNode()

        public Node Search(int data)
        {
            Node p = root;
            while (p != null)
            {
                if (p.data == data)
                    break;
                if (p.data < data)
                    p = p.right;
                if (p.data > data)
                    p = p.left;
            }
            return p;
        }//End of Search(int)

        public void DescPrint(Node p)
        {
            if (p == null) return; 
            DescPrint(p.right);
            Console.Write(p.data + ", ");
            DescPrint(p.left);
        }//End of DescPrint(Node p)

        public int NumPrimes(Node p)
        {
            int count = 0;
            if (p != null)
            {
                bool b = true;
                count += NumPrimes(p.left);
                //Prime Check on p.data
                for (int i = 2; i <= Math.Sqrt(p.data); i++)
                {
                    if (p.data % i == 0) { b = false; break; }
                }
                if (b) count++;
                count += NumPrimes(p.right);
            }
            return count;
        }//End of NumPrimes(Node)


        public void LevelPrint()
        {
            QueNode n = new QueNode(root, 0);
            Que que = new Que(n);
            while (true)
            {
                if (n == null) break;
                if (n.node.left != null) que.Add(new QueNode(n.node.left, n.level + 1));
                if (n.node.right != null) que.Add(new QueNode(n.node.right, n.level + 1));
                n = n.next;
            }
            //Displays level 0,1,2,3 ... in that order
            que.Display();
        }//End of LevelPrint()


        public int FindHeight(Node p)
        {
            int height = 0;
            int hLeft = 0;
            int hRight = 0;
            if(p.left != null)
                hLeft = FindHeight(p.left);
            if (p.right != null)
                hRight = FindHeight(p.right);
            if (hLeft > hRight)
                height = hLeft;
            else
                height = hRight;
            return height + 1;
        }//End of FindHeight(Node)

        public int getSize(Node p)
        {
            if (p == null) return 0;
            return (getSize(p.left) + getSize(p.right) + 1);
        }//End of getSize(Node root)
    }//End of class BST
}
