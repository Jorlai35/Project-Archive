﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_3___Binary_Search_Tree
{
    class Node
    {
        public Node left;
        public Node right;
        public int data;
        public Node(int n)
        {
            data = n;
            left = null;
            right = null;
        }//End of Constructor
    }//End of class Node
}
