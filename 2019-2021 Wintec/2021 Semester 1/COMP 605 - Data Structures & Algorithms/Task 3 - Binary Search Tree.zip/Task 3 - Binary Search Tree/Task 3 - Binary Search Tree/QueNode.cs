﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_3___Binary_Search_Tree
{
    class QueNode
    {
        public QueNode next;
        public Node node;
        public int level;

        public QueNode(Node n, int level)
        {
            node = n;
            this.level = level;
        }
    }
}
