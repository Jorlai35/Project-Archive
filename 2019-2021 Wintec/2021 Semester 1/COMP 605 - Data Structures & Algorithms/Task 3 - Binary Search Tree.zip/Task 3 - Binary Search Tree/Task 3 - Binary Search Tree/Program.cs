﻿using System;
using System.IO;

namespace Task_3___Binary_Search_Tree
{
    class Program
    {
        static void Main(string[] args)
        {
            //Mark - 100
            //Reads the files into respective arrays
            string[] A1 = File.ReadAllLines(@"File1.txt");
            string[] A2 = File.ReadAllLines(@"File2.txt");
            string[] A3 = File.ReadAllLines(@"File3.txt");
            //Creates Binary Search Trees (BST) 
            BST bst1 = new BST();
            BST bst2 = new BST();
            BST bst3 = new BST();
            //Populates the BST's with the data in the arrays
            PopulateBST(bst1, A1);
            PopulateBST(bst2, A2);
            PopulateBST(bst3, A3);
            //Displays the amount of nodes in each BST
            Console.WriteLine("Size of bst1: " + bst1.getSize(bst1.root));
            Console.WriteLine("Size of bst2: " + bst2.getSize(bst2.root));
            Console.WriteLine("Size of bst3: " + bst3.getSize(bst3.root));
            //Displays all data from the BST's
            Console.WriteLine("Values in bst1: ");
            bst1.DescPrint(bst1.root);
            Console.WriteLine("\nValues in bst2: ");
            bst2.DescPrint(bst2.root);
            Console.WriteLine("\nValues in bst3: ");
            bst3.DescPrint(bst3.root);
            //Displays a level by level of the data in each BST
            Console.WriteLine("\nLevel print for bst1: ");
            bst1.LevelPrint();
            Console.WriteLine("\nLevel print for bst2: ");
            bst2.LevelPrint();
            Console.WriteLine("\nLevel print for bst3: ");
            bst3.LevelPrint();
            //Displays the height(How many levels) for each BST
            Console.WriteLine("\nHeight of bst1: " + bst1.FindHeight(bst1.root));
            Console.WriteLine("Height of bst2: " + bst2.FindHeight(bst2.root));
            Console.WriteLine("Height of bst3: " + bst3.FindHeight(bst3.root));
            //Display the total amount of primes in each BST(Counter)
            Console.WriteLine("Amount of primes in bst1: " + bst1.NumPrimes(bst1.root));
            Console.WriteLine("Amount of primes in bst2: " + bst2.NumPrimes(bst2.root));
            Console.WriteLine("Amount of primes in bst3: " + bst3.NumPrimes(bst3.root));
        }

        static void PopulateBST(BST bst, string[] A)
        {
            //loop for creating BST nodes from the data and adding it to the BST
            for(int i = 0; i < A.Length; i++)
            {
                bst.addNode(new Node(Int32.Parse(A[i])));
            }
        }//End of PopulateBST(BST, string[])
    }
}
