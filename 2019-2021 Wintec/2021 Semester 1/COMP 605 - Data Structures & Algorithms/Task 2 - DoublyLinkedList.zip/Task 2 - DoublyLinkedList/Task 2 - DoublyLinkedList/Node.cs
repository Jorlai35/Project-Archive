﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_2___DoublyLinkedList
{
    class Node
    {
        public int data;
        public Node prev;
        public Node next;

        public Node(int d)
        {
            data = d;
        }

        public Node Prev()
        {
            return prev;
        }

        public Node Next()
        {
            return next;
        }

        public void setPrev(Node prev)
        {
            this.prev = prev;
        }

        public void setNext(Node next)
        {
            this.next = next;
        }

        public void setBoth(Node prev, Node next)
        {
            setNext(next);
            setPrev(prev);
        }

        public int getData()
        {
            return data;
        }
    }
}
