﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task_2___DoublyLinkedList
{
    class DLL
    {
        public Node head;
        public Node tail;

        public DLL()
        {

        }

        public void Add(Node d)
        {
            if (head == null && tail == null)
            {
                head = d;
                tail = d;
            } 
            else
            {
                d.setPrev(tail);
                tail.setNext(d);
                tail = d;
            }
        }

        public void AddHead(Node d)
        {
            if (head == null && tail == null)
            {
                head = d;
                tail = d;
            }
            else
            {
                d.setNext(head);
                head.setPrev(d);
                head = d;
            }
        }

        public int Length()
        {
            Node d = head;
            int c = 1;
            while (d != tail)
            {
                d = d.Next();
                c++;
            }
            return c;
        }

        public Node Index(int i)
        {
            Node d = head;
            for (int x = 0; x < i - 1; x++)
            {
                d = d.Next();
            }
            return d;
        }
    }
}
