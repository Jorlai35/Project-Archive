﻿using System;
using System.IO;

namespace Task_2___DoublyLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            //Task 1 : Populating 3 DoublyLinkedLists
            DLL list1 = Populate(File.ReadAllLines(@"file1.txt"), new DLL());
            DLL list2 = Populate(File.ReadAllLines(@"file2.txt"), new DLL());
            DLL list3 = Populate(File.ReadAllLines(@"file3.txt"), new DLL());
            //Task 2 : Display the length of each DLL
            Console.WriteLine("Length of file 1: " + list1.Length());
            Console.WriteLine("Length of file 2: " + list2.Length());
            Console.WriteLine("Length of file 3: " + list3.Length());
            //Task 3 : Display the middle number in each DLL
            Console.WriteLine("Middle of file 1: " + list1.Index(list1.Length() / 2).getData());
            Console.WriteLine("Middle of file 2: " + list2.Index(list2.Length() / 2).getData());
            Console.WriteLine("Middle of file 3: " + list3.Index(list3.Length() / 2).getData());
            //Task 4 : Display the primes in each DLL
            Console.WriteLine("List of primes in list 1: \n" + Range(list1.head));
            Console.WriteLine("List of primes in list 2: \n" + Range(list2.head));
            Console.WriteLine("List of primes in list 3: \n" + Range(list3.head));
            //Task 5 : Display the numbers in each DLL in reverse
            Console.WriteLine("Reverse contents in list 1: \n" + Reverse(list1));
            Console.WriteLine("Reverse contents in list 2: \n" + Reverse(list2));
            Console.WriteLine("Reverse contents in list 3: \n" + Reverse(list3));
            //Task 6 : Display the intersecting values(numbers that appear in all DLLs)
            Console.WriteLine("Values that appear in all lists: \n" + Intersection(list1, list2, list3));
        }

        static DLL Populate(string[] A, DLL list)
        {
            foreach (string s in A)
            {
                list.Add(new Node(Int32.Parse(s)));
            }
            return list;
        }//End of Populate

        static string Range(Node d)
        {
            string s = "";
            int c = 0;
            while (d != null)
            {
                if (isPrime(d.getData()))
                {
                    //Formating display(5 numbers a line)
                    if (c < 4)
                    {
                        s += d.getData() + ", ";
                        c++;
                    }
                    else
                    {
                        s += d.getData() + ", \r\n";
                        c = 0;
                    }
                }
                d = d.Next();
            }
            return s;
        }//End of Range

        static bool isPrime(int n)
        {
            int root = Convert.ToInt32(Math.Sqrt(n));
            bool b = true;
            if (n > 2)
            {
                for (int i = 2; i <= root; i++)
                {
                    if (n % i == 0)
                    {
                        b = false;
                        break;
                    }
                }
            }
            if (n < 2) b = false;
            return b;
        }//End of isPrime

        static string Reverse(DLL list)
        {
            Node d = list.tail;
            string s = "";
            while (d != null)
            {
                s += d.getData() + ", ";
                d = d.Prev();
            }
            return s;
        }//End of Reverse

        static string Intersection(DLL l1, DLL l2, DLL l3)
        {
            string s = "";
            Node d1 = l1.head;
            Node d2 = l2.head;
            Node d3 = l3.head;
            int[] A = new int[l1.Length()];
            int count = 0;
            //Comparing first two DLLs
            while (d1 != null)
            {
                while (d2 != null)
                {
                    if (d1.data == d2.data)
                    {
                        A[count] = d1.data;
                        count++;
                    }
                    d2 = d2.next;
                }
                d2 = l2.head;
                d1 = d1.next;
            }
            //comparing results from first two to the final DLL
            for (int i = 0; i < A.Length; i++)
            {
                while (d3 != null)
                {
                    if (A[i] == d3.data)
                        s += d3.data + ", ";
                    d3 = d3.next;
                }
                d3 = l3.head;
            }
            return s;
        }//End of Intersection
    }
}
