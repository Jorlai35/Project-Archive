﻿using System;
using System.IO;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //creating array and parsing strings to values
            string[] fileContent = File.ReadAllLines(@"file.txt");
            int[] A = new int[fileContent.Length];
            for (int i = 0; i < fileContent.Length; i++)
            {
                A[i] = Int32.Parse(fileContent[i]);
            }
            int min = minNumber(A);
            double avg = 0;
            int pCount = 0;

            //loop for checking a value is prime and totaling for the average
            for (int i = 0; i < A.Length; i++)
            {
                if (checkPrime(A[i])) pCount++;
                avg += A[i];
            }

            //all outputs and calculation for average
            avg = avg / fileContent.Length;
            Console.WriteLine("The minimum number: " + A[min]);
            Console.WriteLine("The minimum number\'s index: " + min);
            Console.WriteLine("The number of primes: " + pCount);
            Console.WriteLine("The average: " + avg);
            Console.WriteLine("The number of evens: " + numEven(A));
            Console.WriteLine("The number of odds: " + numOdd(A));
            Console.WriteLine("The amount above the avg: " + aboveAverage(avg, A));
            Console.WriteLine("Is the numbers the same: " + isEqual(A));
            Console.WriteLine("Is the numbers the unique: " + isDifferent(A));
            Console.WriteLine("Is the numbers sorted: " + isSorted(A));

        }

        //Simple method to check if a value is prime
        static public bool checkPrime(int n)
        {
            bool b = false;
            for (int i = 2; i < Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                {
                    b = true;
                    break;
                }
            }
            return b;
        }

        //Method returns a count of how many even nums in an array
        static public int numEven(int[] A)
        {
            int count = 0;
            foreach (int n in A)
            {
                if (n % 2 == 0)
                    count++;
            }
            return count;
        }

        //Method returns a count of odd in an array
        static public int numOdd(int[] A)
        {
            int count = 0;
            foreach (int n in A)
            {
                if (n % 2 != 0)
                    count++;
            }
            return count;
        }

        // Returns the location of the min number in an array
        static public int minNumber(int[] A)
        {
            int min = 0;
            for (int i = 1; i < A.Length; i++)
            {
                if (A[min] > A[i])
                    min = i;
            }
            return min;
        }

        //Method takes in the avg and an array and returns a count of numbers that are above the avg
        static public int aboveAverage(double n, int[] A)
        {
            int count = 0;
            foreach (int x in A)
            {
                if (x > n)
                    count++;
            }
            return count;
        }

        //Method  checks if all values are equal
        static public bool isEqual(int[] A)
        {
            bool b = true;
            for (int i = 1; i < A.Length; i++)
            {
                if (A[i] != A[i - 1])
                {
                    b = false;
                    break;
                }
            }
            return b;
        }

        //Method checks if all values are unique
        static public bool isDifferent(int[] A)
        {
            bool b = true;
            for (int i = 1; i < A.Length; i++)
            {
                for (int j = 0; j < A.Length; j++)
                {
                    if (i == j) continue;
                    if (A[i] == A[j])
                    {
                        b = false;
                        break;
                    }
                }
                if (b == false) break;
            }
            return b;
        }

        //Method checks if the array is in order
        static public bool isSorted(int[] A)
        {
            bool b = true;
            for (int i = 1; i < A.Length; i++)
            {
                if (A[i] < A[i - 1])
                {
                    b = false;
                    break;
                }
            }
            return b;
        }
    }
}

